const express = require('express');
var app = express();
//var bodyParser = require('body-parser');
const pg = require('pg');
//app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({extended: true}))

//var pgp = require('pg-promise')();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));

const pool = new pg.Pool({
	user: 'postgres',
	host: 'localhost',
	database: 'epups_db',
	password: 'pass',
	port: '5432'
});
var data=[];


pool.query("SELECT * FROM dogs", (err, res) => {
	//console.log(err, res);
	//data[0] = res.rows[0].name;
	for(var i =0; i<res.rows.length;i++){
		data[i]=res.rows[i];
	}
	console.log(data[4].name)
	// res.render('matching',{
	// 	my_title: "Title",
	// 	dog_name: res.rows[1]
	// })
	pool.end();
	//console.log(res.rows[0].name);
});

app.get('/', function(req, res){
	res.render('home',{
		my_title:"Main Page"
	})

});

app.get('/contact', function(req, res){
	res.render('contact',{
		my_title:"Contact",
		dog_name11: data[0].name,
		dog_img11: data[0].img_src
	})

});


app.get('/matching', function(req, res){
	var j = req.query.dog_like;
	res.render('matching',{
		my_title:"Main Page",
		dog_name: data[0].name,
		dog_size: data[0].size,
		dog_age_months: data[0].age_months,
		dog_breed: data[0].breed,
		dog_sex: data[0].sex,
		dog_fee: data[0].fee,
		dog_img: data[0].img_src
	})
	console.log(j);
});
app.get('/matching0', function(req, res){
	var j = req.query.dog_name; // legacy
	res.render('matching0',{
		my_title:"Main Page",
		dog_name_0: data[1].name,
		dog_size_0: data[1].size,
		dog_age_months_0: data[1].age_months,
		dog_breed_0: data[1].breed,
		dog_sex_0: data[1].sex,
		dog_fee_0: data[1].fee,
		dog_img_0: data[1].img_src
	})
	//console.log(data[2]);
});

app.get('/matching1', function(req, res){
	var j = req.query.dog_name;
	res.render('matching1',{
		my_title:"Main Page",
		dog_name_1: data[2].name,
		dog_size_1: data[2].size,
		dog_age_months_1: data[2].age_months,
		dog_breed_1: data[2].breed,
		dog_sex_1: data[2].sex,
		dog_fee_1: data[2].fee,
		dog_img_1: data[2].img_src
	})
});

app.get('/matching2', function(req, res){
	var j = req.query.dog_name;
	res.render('/home/brett/Desktop/Epups/epups/views/matching2',{
		my_title:"Main Page",
		dog_name_2: data[3].name,
		dog_size_2: data[3].size,
		dog_age_months_2: data[3].age_months,
		dog_breed_2: data[3].breed,
		dog_sex_2: data[3].sex,
		dog_fee_2: data[3].fee,
		dog_img_2: data[3].img_src
	})
});


app.get('/matching3', function(req, res){
	var j = req.query.dog_name;
	res.render('/home/brett/Desktop/Epups/epups/views/matching3',{
		my_title:"Main Page",
		dog_name_3: data[4].name,
		dog_size_3: data[4].size,
		dog_age_months_3: data[4].age_months,
		dog_breed_3: data[4].breed,
		dog_sex_3: data[4].sex,
		dog_fee_3: data[4].fee,
		dog_img_3: data[4].img_src
	})
});

app.listen(3000);
//console.log(data);

// const dbConfig = {
// 	host: 'localhost',
// 	database: 'epups_db',
// 	user: 'postgres',
// 	password: 'pass'
// };

// var db = pgp(dbConfig);






//var all_dogs[];

// app.set('view engine', 'ejs');
// app.use(express.static(__dirname + '/'));

// var rows;
//app.get('/', function(req, res){
//	res.send('hello world');
// 	var query = 'select * from dogs;';
// 	console.log('here');
// 	db.any(query)
// 		.then(function (rows){
// 			res.render('epups/matching',{
// 				my_title: "Page title here",
// 				data: rows
// 			})
// 			console.log(rows);
// 		})
// 		.catch(function(err) {
// 			request.flash('error',err);
// 			response.render('epups/matching',{
// 				my_title: "Page title here",
// 				data: ''
// 			})
// 		})
// console.log(rows);
	// db.task('get-everything', task => {
	// 	return task.batch([
	// 		task.any(list_dog)
	// 		]);
	// })
	// .then(data =>{
	// 	console.log(data)
	// 	res.render('/matching',{
	// 		id: data[0],
	// 		name: data[1]
	// 	})
	// })
	// .catch(error =>{
	// 	requeset.flash('error', err);
	// 	response.render('/matching',{
	// 		id: '',
	// 		name: ''
	// 	})
	// });
//});
//console.log(rows);
// db.any('select * from dogs;')
// 	.then(dogs => {
// 		console.log(dogs.name);
// 	})
// 	.catch(error =>{
// 		console.log(error)
// 	});
